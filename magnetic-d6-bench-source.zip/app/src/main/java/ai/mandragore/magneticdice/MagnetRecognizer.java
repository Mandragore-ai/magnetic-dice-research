package ai.mandragore.magneticdice;
import java.util.*;
/** Empirical vectors in one fixed reading zone. No physical-accuracy claim. */
public final class MagnetRecognizer {
 public static final int MIN_POSES=12;
 public static class Sample {public final int face;public final double[] v;public Sample(int f,double[] x){face=f;v=x.clone();}}
 public static class Prediction {public int face=0;public double distance=0,margin=0;public String reason="";}
 public static double norm(double[] x){double s=0;for(double a:x)s+=a*a;return Math.sqrt(s);}
 public static double distance(double[] x,double[] y){double s=0;for(int i=0;i<3;i++){double d=x[i]-y[i];s+=d*d;}return Math.sqrt(s);}
 public static String quality(double[] v,double noise,double stability){
  for(double x:v)if(Double.isNaN(x)||Double.isInfinite(x))return "Valeur invalide";
  if(norm(v)<Math.max(3,6*noise))return "Signal trop faible : rapprocher la zone du capteur, puis refaire toute la calibration";
  if(stability>Math.max(2,Math.max(4*noise,.05*norm(v))))return "Dé ou téléphone instable";
  return null;
 }
 public static Prediction predict(double[] v,double noise,List<Sample> samples){
  Prediction p=new Prediction();String bad=quality(v,noise,0);if(bad!=null){p.reason=bad;return p;}
  int[] counts=new int[7];double[] best=new double[7];Arrays.fill(best,Double.POSITIVE_INFINITY);
  for(Sample s:samples)if(s.face>=1&&s.face<=6){counts[s.face]++;best[s.face]=Math.min(best[s.face],distance(v,s.v));}
  for(int f=1;f<=6;f++){
   if(counts[f]<MIN_POSES){p.reason="Apprendre les six faces : 12 orientations par face minimum";return p;}
   double spread=0;for(Sample a:samples)if(a.face==f)for(Sample b:samples)if(b.face==f)spread=Math.max(spread,distance(a.v,b.v));
   if(spread<Math.max(6,10*noise)){p.reason="Orientations trop semblables pour la face "+f+" : tourner le dé autour de son centre";return p;}
  }
  int win=1;for(int f=2;f<=6;f++)if(best[f]<best[win])win=f;
  double second=Double.POSITIVE_INFINITY;for(int f=1;f<=6;f++)if(f!=win)second=Math.min(second,best[f]);
  p.distance=best[win];p.margin=second-best[win];
  if(p.distance>Math.max(5,Math.max(4*noise,.20*norm(v)))){p.reason="Signature éloignée de l’apprentissage";return p;}
  if(p.margin<Math.max(3,Math.max(5*noise,.10*norm(v)))){p.reason="Plusieurs faces trop proches : indéterminé";return p;}
  p.face=win;p.reason="Face candidate du D6 magnétique, dans la zone apprise";return p;
 }
}
