package ai.mandragore.magneticdice;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONObject;
import java.io.*;

/** Storage required by the magnetic D6 bench only. */
final class GuidedStore {
    static File directory(Context c) throws IOException {
        File base = c.getExternalFilesDir(null);
        if (base == null) throw new IOException("Stockage externe indisponible");
        File dir = new File(base, "guided");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Impossible de créer le dossier de captures");
        return dir;
    }
    static JSONObject read(File file) throws Exception {
        StringBuilder data = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = reader.readLine()) != null) data.append(line);
        }
        return new JSONObject(data.toString());
    }
    static void atomic(File file, JSONObject value) throws Exception {
        AtomicFile atomic = new AtomicFile(file);
        FileOutputStream out = null;
        try {
            out = atomic.startWrite();
            out.write(value.toString(2).getBytes("UTF-8"));
            atomic.finishWrite(out);
        } catch (Exception ex) {
            if (out != null) atomic.failWrite(out);
            throw ex;
        }
    }
}
