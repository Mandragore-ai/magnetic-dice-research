package ai.mandragore.magneticdice;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.support.v4.content.FileProvider;
import android.util.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Single known D6, fixed phone and reading zone; learn independently of blind truth. */
public class MagnetLabActivity extends Activity implements SensorEventListener {
 final Handler ui=new Handler();
 final ArrayList<Button> controls=new ArrayList<>();
 final ArrayList<MagnetRecognizer.Sample> samples=new ArrayList<>();
 final String session=UUID.randomUUID().toString();
 final String model="V19_D6_MAG5x2_COTE20mm_A";
 static final long CAMPAIGN_TTL_MS=12L*60L*60L*1000L;
 SensorManager manager;Sensor sensor;TextView info,live;Spinner face,angle;Button stop;File dir,summaryFile;BufferedWriter writer;JSONObject result;ScrollView scroll;MagnetGuideView guide;
 boolean running=false,measure=false,isBaseline=false,train=false,keepTraining=false;long until,lastStamp,lastArrival;int count,trainingFace,guideHour=4,lastFacePosition=0;double[] mean=new double[3],m2=new double[3],baseline;
 final ArrayList<String> trainingFiles=new ArrayList<>();String referenceFile=null;
 double baselineNoise;String campaign=null;long baselineAt;boolean saturated;int accuracy;

 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  manager=(SensorManager)getSystemService(SENSOR_SERVICE);sensor=manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED);if(sensor==null)sensor=manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
  try{dir=GuidedStore.directory(this);}catch(Exception e){TextView error=new TextView(this);error.setText("Stockage indisponible : "+e);setContentView(error);return;}
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(8),dp(10),dp(12));scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
  TextView title=new TextView(this);title.setText("D6 aimant — gabarit fixe");title.setTextSize(22);root.addView(title);
  TextView note=new TextView(this);note.setText("Choisissez le CHIFFRE VISIBLE SUR LE DESSUS du dé. Téléphone et câble immobiles. Placez le dé sur le dessin, avec le même coin A vers l'heure demandée, puis retirez la main.");root.addView(note);

  face=new Spinner(this);face.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Dessus 1","Dessus 2","Dessus 3","Dessus 4","Dessus 5","Dessus 6"}));
  int savedFace=getPreferences(MODE_PRIVATE).getInt("magnet_face",0);face.setSelection(Math.max(0,Math.min(5,savedFace)));lastFacePosition=face.getSelectedItemPosition();root.addView(face);
  guideHour=getPreferences(MODE_PRIVATE).getInt("magnet_guide_hour",4);if(guideHour<0||guideHour>11)guideHour=4;
  String[] hours=new String[12];hours[0]="12 h — coin A en haut";for(int i=1;i<12;i++)hours[i]=i+" h — coin A vers "+i+" h";
  angle=new Spinner(this);angle.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,hours));angle.setSelection(guideHour);root.addView(angle);
  guide=new MagnetGuideView(this);guide.setHour(guideHour);root.addView(guide,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(330)));
  TextView volume=new TextView(this);volume.setText("VOLUME + : enregistrer la pose affichée");volume.setTextSize(18);volume.setGravity(Gravity.CENTER);volume.setPadding(0,dp(6),0,dp(6));root.addView(volume);
  live=new TextView(this);root.addView(live);info=new TextView(this);info.setTextSize(17);root.addView(info);
  add(root,"1. Calibrer sans aimant (nouvelle campagne)",v->begin(true,false));add(root,"2. Apprendre la face choisie",v->begin(false,true));add(root,"3. Tester à l’aveugle",v->begin(false,false));
  stop=add(root,"Interrompre",v->abort("Interrompu"));add(root,"Progression / bilan",v->progress());add(root,"Exporter les mesures magnétiques",v->export());
  add(root,"Actualiser la référence — conserver les poses",v->begin(true,false,true));

  face.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int position,long id){
   guide.setTopFace(position+1);getPreferences(MODE_PRIVATE).edit().putInt("magnet_face",position).apply();if(position!=lastFacePosition){lastFacePosition=position;setGuideHour(0);}focusGuide();
  }});
  angle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int position,long id){if(position!=guideHour)setGuideHour(position);}});

  String restored=restoreLatestCampaign();
  String sensorText=sensor==null?"Aucun magnétomètre disponible.":"Capteur : "+sensor.getName()+" ; portée "+sensor.getMaximumRange()+" µT.";
  info.setText(restored==null?sensorText+"\nCalibrez sans le dé ni autre aimant à proximité.":sensorText+"\n"+restored);
  enable();ui.post(tick);
 }

 int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
 Button add(LinearLayout root,String t,View.OnClickListener l){Button b=new Button(this);b.setText(t);b.setOnClickListener(l);root.addView(b);controls.add(b);return b;}
 void enable(){for(Button b:controls)b.setEnabled(!running&&sensor!=null);if(stop!=null)stop.setEnabled(running);face.setEnabled(!running);angle.setEnabled(!running);}
 void reset(){count=0;mean=new double[3];m2=new double[3];saturated=false;}
 void setGuideHour(int hour){guideHour=(hour+12)%12;getPreferences(MODE_PRIVATE).edit().putInt("magnet_guide_hour",guideHour).apply();if(angle!=null&&angle.getSelectedItemPosition()!=guideHour)angle.setSelection(guideHour);if(guide!=null)guide.setHour(guideHour);}
 String hourLabel(){return guideHour==0?"12 h":guideHour+" h";}
 void focusGuide(){if(scroll!=null&&guide!=null)scroll.postDelayed(()->scroll.smoothScrollTo(0,Math.max(0,guide.getTop()-dp(10))),120);}

 void begin(boolean base,boolean learning){begin(base,learning,false);}
 void begin(boolean base,boolean learning,boolean preserve){if(running||sensor==null)return;if(!base&&(baseline==null||SystemClock.uptimeMillis()-baselineAt>CAMPAIGN_TTL_MS)){info.setText("Référence expirée. Éloignez le dé, puis utilisez « Actualiser la référence — conserver les poses ».");return;}
  try{isBaseline=base;train=learning;keepTraining=base&&preserve&&campaign!=null;trainingFace=learning?face.getSelectedItemPosition()+1:0;String captureCampaign=base&&!keepTraining?UUID.randomUUID().toString():campaign;
   String id="dice_mag_"+System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,6);summaryFile=new File(dir,id+".json");writer=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(dir,id+".jsonl")),"UTF-8"));
   result=new JSONObject().put("schema","nexuslab.magnet.v1").put("app_version","1.6.18-magnet-resume").put("model_id",model).put("session",session).put("campaign",captureCampaign).put("mode",base?"baseline":learning?"train":"blind").put("training_face",trainingFace).put("face_convention","visible_top_number").put("guide_hour",guideHour).put("guide_degrees",guideHour*30).put("sensor",sensor.getName()).put("sensor_type",sensor.getType()).put("sensor_range_uT",sensor.getMaximumRange()).put("fixed_reading_zone",true).put("usable",false).put("reference_refresh",keepTraining).put("reference_file",referenceFile==null?JSONObject.NULL:referenceFile).put("training_files_before_capture",new JSONArray(trainingFiles));
   if(new File(dir,"dice_mag_corrections.json").exists())result.put("training_corrections",GuidedStore.read(new File(dir,"dice_mag_corrections.json")));
   if(baseline!=null)result.put("baseline",new JSONArray(baseline)).put("baseline_noise_uT",baselineNoise);write(new JSONObject().put("type","metadata").put("data",result));running=true;measure=false;reset();until=SystemClock.uptimeMillis()+6000;lastArrival=SystemClock.uptimeMillis();enable();guide.setStatus(base?"ÉCRAN VIDE":"POSEZ — COIN A VERS "+hourLabel());focusGuide();
  }catch(Exception e){abort("Ouverture impossible : "+e);}
 }

 @Override public boolean onKeyDown(int keyCode,KeyEvent event){if(keyCode==KeyEvent.KEYCODE_VOLUME_UP){if(event.getRepeatCount()==0)begin(false,true);return true;}return super.onKeyDown(keyCode,event);}
 @Override public void onSensorChanged(SensorEvent e){if(e.sensor!=sensor)return;lastArrival=SystemClock.uptimeMillis();live.setText(String.format(Locale.FRANCE,"Champ : %.1f ; %.1f ; %.1f µT",e.values[0],e.values[1],e.values[2]));if(!running)return;
  if(e.timestamp<=lastStamp)return;lastStamp=e.timestamp;
  try{double[] xyz={e.values[0],e.values[1],e.values[2]};write(new JSONObject().put("type","raw").put("sensor_timestamp_ns",e.timestamp).put("phase",measure?"measure":"wait").put("xyz_uT",new JSONArray(xyz)).put("accuracy",e.accuracy));if(!measure)return;
   count++;accuracy=e.accuracy;for(int k=0;k<3;k++){if(Math.abs(xyz[k])>.95*sensor.getMaximumRange())saturated=true;double delta=xyz[k]-mean[k];mean[k]+=delta/count;m2[k]+=delta*(xyz[k]-mean[k]);}
  }catch(Exception ex){abort("Écriture impossible : "+ex);}
 }
 @Override public void onAccuracyChanged(Sensor s,int a){accuracy=a;}
 final Runnable tick=new Runnable(){public void run(){if(running){long now=SystemClock.uptimeMillis();if(now-lastArrival>2000)abort("Aucun échantillon récent");else if(now>=until){if(!measure){measure=true;reset();until=now+3000;}else complete();}
  if(running){long seconds=Math.max(0,(until-now+999)/1000);String phase=measure?"NE BOUGEZ PLUS — "+seconds+" s":isBaseline?"ÉCRAN VIDE — "+seconds+" s":"POSEZ, PUIS RETIREZ LA MAIN — "+seconds+" s";guide.setStatus(phase);info.setText((isBaseline?"SANS AIMANT":train?"APPRENTISSAGE — dessus "+trainingFace+", coin A vers "+hourLabel():"AVEUGLE — résultat libre")+"\n"+phase+"\n"+count+" mesures.");}}
  ui.postDelayed(this,200);}};
 void write(JSONObject j)throws Exception{j.put("wall_time_ms",System.currentTimeMillis());writer.write(j.toString());writer.newLine();}

 void complete(){running=false;enable();try{if(count<30)throw new IOException("Trop peu de mesures : "+count);double variance=0;for(double x:m2)variance+=x;double sd=Math.sqrt(variance/Math.max(1,count-1));
  result.put("samples",count).put("mean_uT",new JSONArray(mean)).put("stability_uT",sd).put("accuracy",accuracy).put("saturated",saturated);if(saturated)throw new IOException("Capteur saturé : éloigner la zone de lecture puis recalibrer");
  if(isBaseline){if(sd>2)throw new IOException("Référence instable : éloigner les sources magnétiques");if(!keepTraining){samples.clear();trainingFiles.clear();}campaign=result.getString("campaign");baseline=mean.clone();baselineNoise=sd;baselineAt=SystemClock.uptimeMillis();referenceFile=summaryFile.getName();result.put("usable",true);guide.setStatus("RÉFÉRENCE ENREGISTRÉE");info.setText("Référence enregistrée. "+samples.size()+" poses conservées. Les anciens apprentissages restent à vérifier après changement de référence. Ne déplacez ni téléphone ni câble.");}
  else{double[] delta=new double[3];for(int i=0;i<3;i++)delta[i]=mean[i]-baseline[i];String bad=MagnetRecognizer.quality(delta,baselineNoise,sd);result.put("delta_uT",new JSONArray(delta)).put("usable",bad==null);
   if(train){if(bad==null){samples.add(new MagnetRecognizer.Sample(trainingFace,delta));trainingFiles.add(summaryFile.getName());}result.put("reason",bad==null?"learned":bad);if(bad==null){guide.setStatus("POSE ENREGISTRÉE");int previous=guideHour;setGuideHour(guideHour+1);info.setText("Dessus "+trainingFace+" appris à "+(previous==0?"12 h":previous+" h")+". Prochaine pose : coin A vers "+hourLabel()+". Volume + pour mesurer.");}else{guide.setStatus("POSE REJETÉE");info.setText("Pose rejetée : "+bad);}}
   else{MagnetRecognizer.Prediction p=MagnetRecognizer.predict(delta,baselineNoise,samples);if(bad!=null){p.face=0;p.reason=bad;}result.put("predicted_face",p.face==0?JSONObject.NULL:p.face).put("distance_uT",p.distance).put("margin_uT",p.margin).put("reason",p.reason).put("prediction_frozen_at_ms",System.currentTimeMillis());guide.setStatus(p.face==0?"INDÉTERMINÉ":"DESSUS "+p.face);info.setText((p.face==0?"INDÉTERMINÉ":"D6 magnétique — dessus "+p.face)+"\n"+p.reason+String.format(Locale.FRANCE,"\nDistance %.2f µT ; marge %.2f µT",p.distance,p.margin));}
  }
  write(new JSONObject().put("type","summary").put("data",result));writer.close();writer=null;GuidedStore.atomic(summaryFile,result);if(!isBaseline&&!train)truth();
 }catch(Exception ex){abort("Mesure rejetée : "+ex.getMessage());}}

 String restoreLatestCampaign(){try{File[] files=dir.listFiles();if(files==null)return null;File latest=null;JSONObject base=null;
   for(File file:files)if(file.getName().startsWith("dice_mag_")&&file.getName().endsWith(".json"))try{JSONObject j=GuidedStore.read(file);if("baseline".equals(j.optString("mode"))&&j.optBoolean("usable")&&(latest==null||captureTime(file)>captureTime(latest))){latest=file;base=j;}}catch(Exception ignored){}
   if(latest==null||base==null)return null;long age=Math.max(0,System.currentTimeMillis()-captureTime(latest));
   JSONArray a=base.getJSONArray("mean_uT");baseline=age>CAMPAIGN_TTL_MS?null:new double[]{a.getDouble(0),a.getDouble(1),a.getDouble(2)};baselineNoise=base.getDouble("stability_uT");campaign=base.getString("campaign");referenceFile=latest.getName();baselineAt=SystemClock.uptimeMillis()-age;samples.clear();trainingFiles.clear();
   File correctionFile=new File(dir,"dice_mag_corrections.json");JSONObject correction=correctionFile.exists()?GuidedStore.read(correctionFile):null;
   HashSet<String> allowed=new HashSet<>();if(correction!=null){JSONArray entries=correction.getJSONArray("training_files");for(int i=0;i<entries.length();i++){String name=entries.getString(i);if(!new File(dir,name).isFile())throw new IOException("Pose corrigée manquante : "+name);allowed.add(name);}}
   for(File file:files)if(file.getName().startsWith("dice_mag_")&&file.getName().endsWith(".json")){JSONObject j;try{j=GuidedStore.read(file);}catch(Exception ignored){continue;}if(!"train".equals(j.optString("mode"))||!j.optBoolean("usable")||!campaign.equals(j.optString("campaign")))continue;int effectiveFace=j.getInt("training_face");
    if(correction!=null&&campaign.equals(correction.getString("campaign"))&&captureTime(file)<=correction.getLong("historical_through_ms")){if(!allowed.contains(file.getName()))continue;if(effectiveFace!=correction.getInt("original_training_face"))throw new IOException("Étiquette originale inattendue");effectiveFace=correction.getInt("corrected_top_face");}
    if(effectiveFace<1||effectiveFace>6)throw new IOException("Face invalide");JSONArray d=j.getJSONArray("delta_uT");samples.add(new MagnetRecognizer.Sample(effectiveFace,new double[]{d.getDouble(0),d.getDouble(1),d.getDouble(2)}));trainingFiles.add(file.getName());}
   int[] byFace=new int[7];for(MagnetRecognizer.Sample s:samples)byFace[s.face]++;StringBuilder restored=new StringBuilder("Poses restaurées (chiffre visible dessus) :\n");for(int f=1;f<=6;f++)restored.append(f+" : "+byFace[f]+"   ");return restored+(baseline==null?"\nRéférence expirée : actualisez-la sans aimant en conservant les poses.":"\nRéférence disponible ; téléphone, câble et zone doivent rester immobiles.");
  }catch(Exception e){baseline=null;campaign=null;samples.clear();trainingFiles.clear();return "Restauration impossible : "+e.getMessage()+". Vérifier les données avant de continuer.";}}
 long captureTime(File file){try{return Long.parseLong(file.getName().split("_")[2]);}catch(Exception e){return file.lastModified();}}

 void truth(){final JSONObject trial=result;final File file=summaryFile;String[] choices={"Dessus 1","Dessus 2","Dessus 3","Dessus 4","Dessus 5","Dessus 6","Vide / objet inconnu"};new AlertDialog.Builder(this).setTitle("Vérité terrain après prédiction figée").setItems(choices,(dlg,which)->{try{int actual=which<6?which+1:0;int predicted=trial.optInt("predicted_face",0);trial.put("ground_truth",actual).put("evaluation_only",true).put("correct",actual==predicted);GuidedStore.atomic(file,trial);info.append("\nVérification : "+(actual==predicted?"conforme":predicted==0?"indéterminé":"ERREUR")+". L’apprentissage reste inchangé.");}catch(Exception ex){info.append("\nSauvegarde impossible : "+ex);}}).setNegativeButton("Non renseigné",null).show();}
 void progress(){int[] c=new int[7];for(MagnetRecognizer.Sample s:samples)c[s.face]++;StringBuilder t=new StringBuilder("Campagne actuelle — poses par face :\n");for(int f=1;f<=6;f++)t.append(f+" : "+c[f]+" / 12 minimum\n");int total=0,ok=0,unknown=0;File[] files=dir.listFiles();if(files!=null)for(File file:files)if(file.getName().startsWith("dice_mag_")&&file.getName().endsWith(".json"))try{JSONObject j=GuidedStore.read(file);if(!j.has("ground_truth")||!j.optString("mode").equals("blind")||!j.optString("campaign").equals(campaign))continue;total++;if(j.optBoolean("correct"))ok++;if(j.isNull("predicted_face"))unknown++;}catch(Exception ignored){}
  t.append("\nEssais aveugles renseignés : "+total+"\nConformes (y compris rejet du vide) : "+ok+"\nIndéterminés : "+unknown+"\nAucune performance générale attestée.");new AlertDialog.Builder(this).setTitle("D6 aimant").setMessage(t).setPositiveButton("Fermer",null).show();}
 void abort(String why){running=false;enable();guide.setStatus(why.toUpperCase(Locale.FRANCE));if(writer!=null)try{result.put("usable",false).put("aborted",why);write(new JSONObject().put("type","abort").put("reason",why));writer.close();writer=null;GuidedStore.atomic(summaryFile,result);}catch(Exception ignored){}info.setText(why);}
 static void copy(InputStream in,OutputStream out)throws IOException{byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
 void export(){try{File out=new File(dir,"dice_mag_export_"+System.currentTimeMillis()+".zip");try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(out))){File[] files=dir.listFiles();if(files!=null)for(File f:files)if(f.getName().startsWith("dice_mag_")&&(f.getName().endsWith(".json")||f.getName().endsWith(".jsonl"))){z.putNextEntry(new ZipEntry(f.getName()));try(InputStream in=new FileInputStream(f)){copy(in,z);}z.closeEntry();}}
   Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/zip");send.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",out));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Transmettre les mesures magnétiques"));
  }catch(Exception e){info.setText("Export impossible : "+e);}}
 @Override protected void onResume(){super.onResume();if(sensor!=null)manager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_GAME);}
 @Override protected void onPause(){if(running)abort("Application quittée pendant la capture");manager.unregisterListener(this);super.onPause();}
 @Override protected void onDestroy(){ui.removeCallbacks(tick);super.onDestroy();}

 /** Physical 20 mm face guide with a stable reference corner and 12 clock positions. */
 static final class MagnetGuideView extends View {
  final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int hour=4,topFace=1;String status="ALIGNER LE COIN A";
  MagnetGuideView(Context c){super(c);setBackgroundColor(Color.rgb(248,248,248));}
  void setHour(int value){hour=(value+12)%12;invalidate();}
  void setTopFace(int value){topFace=value;invalidate();}
  void setStatus(String value){if(value!=null&&!value.equals(status)){status=value;invalidate();}}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h*.55f;DisplayMetrics dm=getResources().getDisplayMetrics();float pxPerMm=((dm.xdpi+dm.ydpi)/2f)/25.4f;float side=20f*pxPerMm;if(side<120||side>w*.62f)side=Math.min(w*.48f,220f*dm.density/3f);float r=side/(float)Math.sqrt(2);
   p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(30,30,30));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(16*dm.scaledDensity);c.drawText("DESSUS VISIBLE : "+topFace,cx,24*dm.density,p);
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f*dm.density);p.setColor(Color.rgb(155,155,155));float clockR=Math.min(w*.39f,r+34*dm.density);c.drawCircle(cx,cy,clockR,p);
   p.setTextSize(12*dm.scaledDensity);p.setTextAlign(Paint.Align.CENTER);p.setStyle(Paint.Style.FILL);for(int i=0;i<12;i++){double a=Math.toRadians(-90+i*30);float x=cx+(clockR+13*dm.density)*(float)Math.cos(a),y=cy+(clockR+13*dm.density)*(float)Math.sin(a)+4*dm.density;c.drawText(i==0?"12":String.valueOf(i),x,y,p);}
   double rot=Math.toRadians(-90+hour*30);Path square=new Path();float ax=0,ay=0;for(int i=0;i<4;i++){double a=rot+i*Math.PI/2;float x=cx+r*(float)Math.cos(a),y=cy+r*(float)Math.sin(a);if(i==0){square.moveTo(x,y);ax=x;ay=y;}else square.lineTo(x,y);}square.close();
   p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(26,0,80,170));c.drawPath(square,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*dm.density);p.setColor(Color.rgb(0,70,150));c.drawPath(square,p);
   p.setStrokeWidth(1.5f*dm.density);c.drawLine(cx-12*dm.density,cy,cx+12*dm.density,cy,p);c.drawLine(cx,cy-12*dm.density,cx,cy+12*dm.density,p);p.setStyle(Paint.Style.FILL);c.drawCircle(cx,cy,3*dm.density,p);
   p.setColor(Color.rgb(210,30,30));c.drawCircle(ax,ay,7*dm.density,p);p.setTextSize(15*dm.scaledDensity);p.setTextAlign(Paint.Align.CENTER);c.drawText("A",ax,ay-11*dm.density,p);
   p.setColor(Color.rgb(30,30,30));p.setTextSize(18*dm.scaledDensity);c.drawText("COIN A VERS "+(hour==0?"12 H":hour+" H"),cx,h-42*dm.density,p);p.setTextSize(15*dm.scaledDensity);p.setColor(Color.rgb(145,0,0));c.drawText(status,cx,h-16*dm.density,p);
  }
 }
}
