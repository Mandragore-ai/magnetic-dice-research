# Magnetic D6 Bench

Standalone Android source for the single magnetic D6 experiment. It reads the Android magnetometer, records an empty baseline, learns six faces at guided orientations, performs blind tests and exports only `dice_mag_*` captures. It contains no capacitive fiducial code.

Build with JDK 8, Android SDK 28, Gradle 4.10.1 and Android Gradle plugin 3.3.2. From this directory run `gradle assembleDebug`. Install `app/build/outputs/apk/debug/app-debug.apk`. The source was isolated from the local NexusLab app on 2026-11-06; the algorithm is the same, while the package name and storage helper were reduced for this standalone build. A build is not a physical validation on other phones.

See the repository README for the hardware protocol and limitations. Source license: MIT; see LICENSE.
